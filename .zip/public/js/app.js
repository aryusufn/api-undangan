document.addEventListener('DOMContentLoaded', () => {
    const INFO = document.getElementById('information');
    INFO.innerText = 'Hub WA 085 784 608 841 || aryusufn.my.id';
});